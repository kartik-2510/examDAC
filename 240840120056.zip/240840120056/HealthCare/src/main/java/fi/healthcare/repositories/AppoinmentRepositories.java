package fi.healthcare.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import fi.healthcare.entity.Appointment;

@Repository
public interface AppoinmentRepositories extends JpaRepository<Appointment, Integer> {

}
