package fi.healthcare.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "appointments")
public class Appointment {
	@Id
	@Column(name = "appointment_id")
	int appointmentId;

	@Column(name = "patient_name")
	String patientName;

	@Column(name = "doctor")
	String doctor;

	@Column(name = "date")
	String date;

	@Column(name = "time")
	String time;

	public Appointment(int appointmentId, String patientName, String doctor, String date, String time) {
		super();
		this.appointmentId = appointmentId;
		this.patientName = patientName;
		this.doctor = doctor;
		this.date = date;
		this.time = time;
	}

	public Appointment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getAppointmentId() {
		return appointmentId;
	}

	public void setAppointmentId(int appointmentId) {
		this.appointmentId = appointmentId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getDoctor() {
		return doctor;
	}

	public void setDoctor(String doctor) {
		this.doctor = doctor;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

}
