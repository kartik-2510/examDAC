package fi.healthcare.dto;

public class AppointmentDTO {
	int appointmentId;
	String patientName;
	String doctor;
	String date;

	String time;

	public AppointmentDTO(int appointmentId, String patientName, String doctor, String date, String time) {
		super();
		this.appointmentId = appointmentId;
		this.patientName = patientName;
		this.doctor = doctor;
		this.date = date;
		this.time = time;
	}

	public AppointmentDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getAppointmentId() {
		return appointmentId;
	}

	public void setAppointmentId(int appointmentId) {
		this.appointmentId = appointmentId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getDoctor() {
		return doctor;
	}

	public void setDoctor(String doctor) {
		this.doctor = doctor;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

}
