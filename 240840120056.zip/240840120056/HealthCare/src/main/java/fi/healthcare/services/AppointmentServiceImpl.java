package fi.healthcare.services;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fi.healthcare.dto.AppointmentDTO;
import fi.healthcare.entity.Appointment;
import fi.healthcare.repositories.AppoinmentRepositories;

@Service
public class AppointmentServiceImpl implements AppointmentService {

	@Autowired
	AppoinmentRepositories repository;

	@Override
	public String scheduleAppointment(AppointmentDTO dto) {
		Appointment appointment = new Appointment();
		BeanUtils.copyProperties(dto, appointment);
		repository.save(appointment);
		return "Appointment registered successfully";
	}

	@Override
	public List<AppointmentDTO> allAppointments() {
		Iterator<Appointment> iter = repository.findAll().iterator();
		ArrayList<AppointmentDTO> finalList = new ArrayList<AppointmentDTO>();
		while (iter.hasNext()) {
			Appointment appointment = iter.next();
			AppointmentDTO dto = new AppointmentDTO();
			BeanUtils.copyProperties(appointment, dto);
			finalList.add(dto);
		}

		return finalList;
	}

	@Override
	public String deleteAppointment(int appointmentId) {
		Appointment appointment = repository.findById(appointmentId).get();
		repository.delete(appointment);
		return "Appointment removed successfullly";
	}

}
