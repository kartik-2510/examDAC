package fi.healthcare.services;

import java.util.List;

import fi.healthcare.dto.AppointmentDTO;

public interface AppointmentService {

	public String scheduleAppointment(AppointmentDTO dto);

	public List<AppointmentDTO> allAppointments();

	public String deleteAppointment(int appointmentId);

}
